from fastapi import FastAPI
from sqlalchemy.schema import MetaData
from starlette.datastructures import Secret


app: FastAPI = FastAPI()
