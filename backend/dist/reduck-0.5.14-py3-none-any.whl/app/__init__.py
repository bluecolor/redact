from .cli import duck

