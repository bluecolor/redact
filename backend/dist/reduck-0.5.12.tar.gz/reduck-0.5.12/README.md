# DUCK

Online data masking and sensitve data discovery platform for common rdbms.

## Supported Databases

- [x] Oracle
- [ ] SQLServer
- [ ] PostgreSQL
- [ ] MySQL


## Commands
`duck --help`


## LICENCE

[Attribution-NonCommercial-ShareAlike 4.0 International](https://creativecommons.org/licenses/by-nc-sa/4.0/)
![licence](https://mirrors.creativecommons.org/presskit/buttons/88x31/png/by-nc-nd.png)
